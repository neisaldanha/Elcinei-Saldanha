<?php $__env->startSection('conteudo'); ?>

<section>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger alert-dismissible bg-danger" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>OPS!</strong> Ocorreu um erro ao salvar.
                <?php if(count($errors) > 0): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>						
        </div>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible bg-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Sucesso!</strong> Operação realizada com sucesso.
            
            <?php if(count($errors) > 0): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

        </div>
    <?php endif; ?>
    <?php echo e(Form::model($usuario, ['method' => 'PATCH','route'=>['cad-usuario.update',$usuario['COD_USUARIO']], 'id' => 'cliente', 'class' => 'cadastro', 'files' => true])); ?>

        
        <div class="col-12">
            <button type="submit" class="btn btn-secondary my-2 mr-1" title="Salvar"><i class="fas fa-save"></i></button>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Excluir"><i class="fas fa-trash"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Imprimir"><i class="fas fa-print"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Simular Preço"><i class="fas fa-calculator"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Histórico de Compras"><i class="fas fa-truck"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Histórico de Vendas"><i class="fas fa-cart-arrow-down"></i></a>
        </div>
        <?php echo Form::hidden('CELULAR', $usuario['COD_USUARIO']); ?>

       <!-- Informações Gerais -->
        <div class="form-group"></div>
        <div class="row" id="fisica">
            <div class="form-group col-md-4">
                <?php echo Form::label('CPF', 'CPF', ['class' => 'fw-5 mb-1']); ?>

                <?php echo Form::text('CPF', $usuario['CPF'], array('id'=>'CPF', 'class' => 'form-control ', 'placeholder' => 'Somente Nº', 'autocomplete' => 'off')); ?>

            </div>
            <div class="form-group col-md-6">
                <?php echo Form::label('DES_NOME', 'Nome', ['class' => 'fw-5 mb-1']); ?>

                <?php echo Form::text('DES_NOME',$usuario['DES_NOME'], array( 'class' => 'form-control', 'placeholder' => 'Nome completo', 'autocomplete' => 'off')); ?>

            </div>
        </div>
       <h4>Contato</h4>
        <div class="form-group"></div>
        <div class="row">
            <div class="form-group col-md-3">
                <?php echo Form::label('CELULAR', 'Celular', ['class' => 'fw-5 mb-1']); ?>

                <?php echo Form::text('CELULAR', $usuario['CELULAR'], array( 'class' => 'form-control', 'placeholder' => 'Celular', 'autocomplete' => 'off')); ?>

            </div>                                
            <div class="form-group col-md-6">
                <?php echo Form::label('EMAIL', 'E-Mail', ['class' => 'fw-5 mb-1']); ?>

                <?php echo Form::text('EMAIL', $usuario['EMAIL'], array('class' => 'form-control', 'placeholder' => 'exemplo@exemplo.com', 'autocomplete' => 'off')); ?>

            </div>
        </div>
        <div class="form-group"></div>
    <?php echo e(Form::close()); ?>

</section>

<?php $__env->stopSection(); ?>
   
<?php $__env->startSection('scripts'); ?>
    
<script src="<?php echo e(asset('js/cliente.js')); ?>"></script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>